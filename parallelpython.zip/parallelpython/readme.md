### Exercises:

E1. ***Basic threading ***

E2. ***Banking program***

E3. ***Multi priority queue***

E4. ***Producer consumer***

### Execution

`python <filename>`