### Exercises:

E1. ***WAPIJ to print main thread properties such as ID, name, status etc.***

E2. ***WAPIJ to create and start additional thread extending Thread class***

E3. ***WAPIJ to create and start additional thread implementing Runnable interface***

E4. ***WAPIJ to illustrate thread sleeping and getting interrupted***

E5. ***WAPIJ to illustrate joining of threads***

E6. ***WAPIJ to do multiple deposits and withdrawal of different values  by different threads (10+) to an account balance implementing correctly and naivly while maintaining a minimum balance of 1000 Rs.***

E7. ***WAPIJ to repeat exercises six above with coarse and fine grained synchronization and observe and plot impact on speed.***


### Execution:

'java <filename>'