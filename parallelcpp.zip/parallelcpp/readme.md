### Exercises:

E1. ***Dining philosopher problem***

E2. ***Sleeping barber***

E3. ***Reader writer problem***

E4. ***Bounded buffer program***

### Execution:

`g++ <filename> -lpthread`


`./a.out`