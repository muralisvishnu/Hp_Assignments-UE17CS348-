### Exercises:

E1. ***Convert colour image to greyscale***

E2. ***Parallel algorithm to blur images***

E3. ***Parallel algorithm for tone mapping***

E4. ***Parallel algorithm to remove red eye effect***

### Execution:

`nvcc <filename> <set architecture if necessary> `

`./a.out`
